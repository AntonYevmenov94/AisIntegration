<?php
return [
    'controllers' => [
        'value' => [
            'namespaces' => [
                '\\Icodes\\ChatWordHints\\Controller' => 'ajax'
            ]
        ],
        'readonly' => true
    ]
];