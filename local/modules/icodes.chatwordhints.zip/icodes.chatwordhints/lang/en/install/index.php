<?
$MESS["ICODES_CHATWH_MODULE_NAME"] = "Подсказки к словам в чате";
$MESS["ICODES_CHATWH_MODULE_DESC"] = "Модуль для отображения всплывающих подсказок к словам в чате";
$MESS["ICODES_CHATWH_PARTNER_NAME"] = "";
$MESS["ICODES_CHATWH_PARTNER_URI"] = "";
$MESS["ICODES_CHATWH_INSTALL_ERROR_VERSION"] = "Версия модуля main ниже 14.0.15 не поддерживается. Пожалуйста, обновите систему.";
?>