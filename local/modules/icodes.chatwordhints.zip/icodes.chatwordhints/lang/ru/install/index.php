<?
$MESS["ICODES_CHATWH_MODULE_NAME"] = "Chat hint words";
$MESS["ICODES_CHATWH_MODULE_DESC"] = "A module for displaying hints to words in a chat";
$MESS["ICODES_CHATWH_PARTNER_NAME"] = "";
$MESS["ICODES_CHATWH_PARTNER_URI"] = "";
$MESS["ICODES_CHATWH_INSTALL_ERROR_VERSION"] = "The main module version below 14.0.15 is not supported. Please update the system.";
?>